<img src="{{ asset('icon_xs.png') }}" alt="Sogar" {{ $attributes->merge(['class' => 'h-8 w-8 object-contain']) }}>
